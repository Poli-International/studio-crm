<?php

namespace App\Services;

class ToolIntegrationService
{
    /**
     * Integration with Tool #14 (Form Builder).
     * Opens the Form Builder tool for creating custom consultation forms.
     *
     * @return array Form Builder integration details
     */
    public function getFormBuilderIntegration()
    {
        return [
            'tool_name' => 'Consultation Form Builder',
            'tool_url' => 'https://poliinternational.com/wp-content/standalone-tools/form-builder/index.html',
            'embed_url' => 'https://poliinternational.com/wp-content/standalone-tools/form-builder/embed.html',
            'description' => 'Create custom consultation and waiver forms with drag-and-drop builder',
            'features' => [
                'Drag-and-drop form builder',
                'PDF export with branding',
                'Digital signature capture',
                'Pre-built templates (medical history, consent, waiver, aftercare)',
                'Custom field types',
                'Conditional logic',
                'Multi-step forms'
            ]
        ];
    }

    /**
     * Get recommended form templates for studio operations.
     * These templates can be created in the Form Builder tool.
     *
     * @return array List of recommended form templates
     */
    public function getRecommendedFormTemplates()
    {
        return [
            [
                'id' => 'tattoo-consent',
                'name' => 'Tattoo Consent Form',
                'description' => 'Standard consent form for tattoo procedures',
                'required_fields' => ['client_name', 'date_of_birth', 'medical_conditions', 'signature']
            ],
            [
                'id' => 'piercing-consent',
                'name' => 'Piercing Consent Form',
                'description' => 'Consent form for piercing procedures',
                'required_fields' => ['client_name', 'date_of_birth', 'allergies', 'piercing_location', 'signature']
            ],
            [
                'id' => 'minor-consent',
                'name' => 'Minor Consent Form',
                'description' => 'Parental consent for clients under 18',
                'required_fields' => ['minor_name', 'minor_dob', 'parent_name', 'parent_signature', 'id_verification']
            ],
            [
                'id' => 'medical-history',
                'name' => 'Medical History Form',
                'description' => 'Comprehensive medical history intake',
                'required_fields' => ['medications', 'conditions', 'allergies', 'blood_disorders', 'skin_conditions']
            ],
            [
                'id' => 'aftercare-acknowledgment',
                'name' => 'Aftercare Instructions Acknowledgment',
                'description' => 'Client acknowledges receipt of aftercare instructions',
                'required_fields' => ['procedure_type', 'instructions_received', 'signature', 'date']
            ]
        ];
    }

    /**
     * Check artist availability in the CRM calendar.
     * Can be called by external booking systems.
     *
     * @param int $artistId Staff member ID
     * @param string $date Date in Y-m-d format
     * @param int $durationMinutes Appointment duration
     * @return array Availability status and time slots
     */
    public function checkAvailability($artistId, $date, $durationMinutes = 60)
    {
        // In production, this would query the appointments table
        // For now, returns a structured response format

        $dayOfWeek = date('N', strtotime($date));
        $isWeekend = ($dayOfWeek == 6 || $dayOfWeek == 7);

        // Define business hours
        $businessHours = [
            'weekday' => ['start' => '10:00', 'end' => '19:00'],
            'saturday' => ['start' => '11:00', 'end' => '18:00'],
            'sunday' => 'closed'
        ];

        if ($dayOfWeek == 7) {
            return [
                'available' => false,
                'reason' => 'Studio closed on Sundays',
                'next_available_date' => date('Y-m-d', strtotime($date . ' +1 day'))
            ];
        }

        $hours = $dayOfWeek == 6 ? $businessHours['saturday'] : $businessHours['weekday'];

        // In production, query appointments table to find available slots
        // Example query: SELECT * FROM appointments WHERE staff_id = ? AND date = ?

        return [
            'available' => true,
            'artist_id' => $artistId,
            'date' => $date,
            'business_hours' => $hours,
            'available_slots' => $this->generateTimeSlots($hours['start'], $hours['end'], $durationMinutes),
            'note' => 'Check with studio for real-time availability'
        ];
    }

    /**
     * Generate available time slots for booking.
     *
     * @param string $start Start time (H:i format)
     * @param string $end End time (H:i format)
     * @param int $duration Slot duration in minutes
     * @return array Available time slots
     */
    private function generateTimeSlots($start, $end, $duration)
    {
        $slots = [];
        $current = strtotime($start);
        $endTime = strtotime($end);

        while ($current < $endTime) {
            $slots[] = date('H:i', $current);
            $current = strtotime("+{$duration} minutes", $current);
        }

        return $slots;
    }

    /**
     * Get link to open Form Builder with pre-filled client data.
     *
     * @param array $clientData Client information
     * @return string URL to Form Builder with query parameters
     */
    public function getFormBuilderLink($clientData = [])
    {
        $baseUrl = 'https://poliinternational.com/wp-content/standalone-tools/form-builder/index.html';

        // Build query string with client data
        $params = [];
        if (!empty($clientData['name'])) {
            $params['client_name'] = urlencode($clientData['name']);
        }
        if (!empty($clientData['email'])) {
            $params['client_email'] = urlencode($clientData['email']);
        }
        if (!empty($clientData['phone'])) {
            $params['client_phone'] = urlencode($clientData['phone']);
        }

        if (!empty($params)) {
            $baseUrl .= '?' . http_build_query($params);
        }

        return $baseUrl;
    }
}
