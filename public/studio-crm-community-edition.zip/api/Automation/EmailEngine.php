<?php

namespace App\Automation;

use App\Models\Service;
use App\Models\EmailQueue;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class EmailEngine
{
    /**
     * Schedule all follow-up emails for a new service.
     */
    public static function scheduleFollowUps($service)
    {
        $date = Carbon::parse($service->date_completed);
        $client = $service->client;

        if ($service->type === 'tattoo') {
            self::addToQueue($client->id, $service->id, 'tattoo-welcome', $date->copy()->addHours(2));
            self::addToQueue($client->id, $service->id, 'tattoo-checkin-3d', $date->copy()->addDays(3));
            self::addToQueue($client->id, $service->id, 'tattoo-aftercare-7d', $date->copy()->addDays(7));
            self::addToQueue($client->id, $service->id, 'tattoo-touchup-reminder', $date->copy()->addMonths(6));
        }
        
        if ($service->type === 'piercing') {
            self::addToQueue($client->id, $service->id, 'piercing-fresh', $date->copy()->addHours(2));
            self::addToQueue($client->id, $service->id, 'piercing-checkup', $date->copy()->addWeeks(2));
        }

        // Add more flows here for removal, touchups, etc.
    }

    /**
     * Add a single email to the queue.
     */
    private static function addToQueue($clientId, $serviceId, $templateSlug, $scheduledFor)
    {
        EmailQueue::create([
            'client_id' => $clientId,
            'service_id' => $serviceId,
            'template_slug' => $templateSlug,
            'scheduled_for' => $scheduledFor,
            'status' => 'pending'
        ]);
    }

    /**
     * Send an email (called by the queue processor).
     */
    public static function sendEmail($queueItem)
    {
        try {
            $client = $queueItem->client;
            $templateContent = self::renderTemplate($queueItem);
            
            // In production, use Laravel Mail::send
            // Mail::to($client->email)->send(new FollowUpEmail($templateContent));
            
            // For MVP: Simulation
            $log = "[".date('Y-m-d H:i:s')."] SENT '{$queueItem->template_slug}' TO {$client->email}\n";
            file_put_contents(__DIR__.'/../../logs/email.log', $log, FILE_APPEND);

            $queueItem->update(['status' => 'sent', 'sent_at' => now()]);
            return true;
        } catch (\Exception $e) {
            $queueItem->update(['status' => 'failed', 'error_log' => $e->getMessage()]);
            return false;
        }
    }

    /**
     * Render the email HTML by replacing placeholders.
     */
    private static function renderTemplate($queueItem)
    {
        $base = file_get_contents(__DIR__.'/../../email-templates/base.html');
        $content = file_get_contents(__DIR__.'/../../email-templates/'.$queueItem->template_slug.'.html');

        // Merge content into base
        $html = str_replace('{{CONTENT}}', $content, $base);

        // Replace global variables
        $html = str_replace('{{STUDIO_NAME}}', 'Poli Tattoo Studio', $html);
        $html = str_replace('{{YEAR}}', date('Y'), $html);
        
        // Replace client variables
        $html = str_replace('{{CLIENT_NAME}}', $queueItem->client->name, $html);
        
        return $html;
    }
}
