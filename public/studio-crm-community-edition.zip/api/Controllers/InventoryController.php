<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Inventory;

class InventoryController extends Controller
{
    public function index()
    {
        return response()->json(Inventory::all());
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'item_type' => 'required|in:needle,ink,jewelry,supply,equipment',
            'quantity' => 'required|integer',
            'reorder_point' => 'required|integer'
        ]);
        
        return response()->json(Inventory::create($validated), 201);
    }
    
    public function lowStockAlerts()
    {
        $lowStock = Inventory::whereColumn('quantity', '<=', 'reorder_point')->get();
        return response()->json($lowStock);
    }
    
    public function restock(Request $request, $id)
    {
        $request->validate(['quantity' => 'required|integer|min:1']);
        
        $item = Inventory::findOrFail($id);
        $item->increment('quantity', $request->quantity);
        
        return response()->json($item);
    }
}
