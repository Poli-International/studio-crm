import os
import ftplib
import re
from pathlib import Path

# --- Configuration ---
SOURCE_DIR = Path("c:/Users/Patrick/poli-international/standalone-tools/studio-crm-laravel")
CREDENTIALS_FILE = Path("c:/Users/Patrick/poli-international/January_06-2026-Credentials.md")
REMOTE_BASE_PATH = "/domains/poliinternational.com/public_html/wp-content/standalone-tools/studio-crm"

# Files to patch
FILES_TO_UPLOAD = [
    "resources/views/landing.blade.php",
    "resources/views/layouts/app.blade.php",
    "resources/views/auth/login.blade.php",
    "resources/views/auth/register.blade.php"
]

# --- Credentials Extraction ---
def get_credentials():
    with open(CREDENTIALS_FILE, 'r', encoding='utf-8') as f:
        content = f.read()
    
    ftp_host = re.search(r"\*\*Host:\*\* ([\d\.]+)", content).group(1)
    ftp_user = re.search(r"\*\*Username:\*\* (\w+)", content).group(1)
    ftp_pass = re.search(r"\*\*Password:\*\* ([^\s\n]+)", content).group(1)
    
    return {'host': ftp_host, 'user': ftp_user, 'pass': ftp_pass}

# --- FTP Upload ---
def upload_patch(ftp_creds):
    print(f"Connecting to FTP {ftp_creds['host']}...")
    ftp = ftplib.FTP(ftp_creds['host'])
    ftp.login(ftp_creds['user'], ftp_creds['pass'])
    
    for file_path in FILES_TO_UPLOAD:
        local_file = SOURCE_DIR / file_path
        
        # Ensure proper remote path
        if file_path == "resources/views/gallery/index.blade.php":
            remote_file = f"{REMOTE_BASE_PATH}/{file_path}"
        else:
            remote_file = f"{REMOTE_BASE_PATH}/{file_path}"
            
        print(f"Uploading {file_path} to {remote_file}...")
        
        # Ensure dir exists
        remote_dir = os.path.dirname(remote_file)
        try:
            # Simple check, might fail if parent dirs don't exist but for patch expected to be ok
            ftp.cwd(remote_dir)
        except:
             # Try to make it?
             pass # Assuming structure exists from previous deploy

        with open(local_file, 'rb') as f:
            # Need to go to the directory first or full path?
            # ftp.storbinary usually takes filename in current dir
            # Or absolute path if supported.
            # Safest to cwd to the dir.
            
            # Reset to root? No, we have absolute paths in REMOTE_BASE_PATH but ftplib uses CWD
            
            # Let's try direct CWD to the target directory
            target_dir = os.path.dirname(remote_file)
            try:
                ftp.cwd(target_dir)
            except Exception as e:
                print(f"Could not cwd to {target_dir}: {e}")
                continue
                
            ftp.storbinary(f"STOR {os.path.basename(file_path)}", f)

    ftp.quit()
    print("Patch Upload Complete.")

def main():
    try:
        creds = get_credentials()
        upload_patch(creds)
        print("\nPatch Deployed Successfully!")
    except Exception as e:
        print(f"Error during patching: {e}")

if __name__ == "__main__":
    main()
