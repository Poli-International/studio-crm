# Installation Instructions

## Requirements
*   PHP 7.4 or higher
*   MySQL 5.7 or higher
*   Apache or Nginx web server

## Installation Steps

1.  **Upload Files**
    *   Upload all files to your web server (public_html).

2.  **Create Database**
    *   Log in to your hosting control panel (cPanel, etc).
    *   Create a new MySQL database and user.

3.  **Run Installer**
    *   Navigate to `http://your-domain.com/install.php`.
    *   Enter the database credentials you just created.
    *   Create your Admin account.

4.  **Security**
    *   **IMPORTANT**: Delete `install.php` after installation is complete!

5.  **Cron Job (For Email Automation)**
    *   Set up a cron job to run every hour:
    *   `php /path/to/studio-crm/cron/process_email_queue.php`

## Integration
*   To enable Google Calendar sync, go to **Settings > Integrations**.
