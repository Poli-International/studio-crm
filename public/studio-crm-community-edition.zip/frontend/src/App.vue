<script setup>
import { RouterView } from 'vue-router'
import Sidebar from './components/Sidebar.vue'
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
// Don't show sidebar on login page
const showSidebar = computed(() => route.name !== 'login')
</script>

<template>
  <div class="layout">
    <Sidebar v-if="showSidebar" />
    
    <main class="main-content" :class="{ 'full-width': !showSidebar }">
      <RouterView />
    </main>
  </div>
</template>

<style scoped>
.layout {
  display: flex;
  width: 100%;
  height: 100vh;
  overflow: hidden;
}

.main-content {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
  background-color: var(--bg-body);
}

.full-width {
  padding: 0;
}
</style>
