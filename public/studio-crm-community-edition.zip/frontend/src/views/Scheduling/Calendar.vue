<script setup>
import { ref } from 'vue'
import FullCalendar from '@fullcalendar/vue3'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'

const calendarOptions = ref({
  plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
  initialView: 'timeGridWeek',
  headerToolbar: {
    left: 'prev,next today',
    center: 'title',
    right: 'dayGridMonth,timeGridWeek,timeGridDay'
  },
  events: [
    { title: 'Tattoo - John Doe', start: new Date().setHours(10,0,0), end: new Date().setHours(13,0,0), backgroundColor: '#3B82F6' },
    { title: 'Piercing - Sarah', start: new Date().setHours(14,0,0), end: new Date().setHours(14,30,0), backgroundColor: '#8B5CF6' }
  ],
  editable: true,
  selectable: true,
  select: handleDateSelect,
  eventClick: handleEventClick
})

function handleDateSelect(selectInfo) {
  let title = prompt('Enter Client Name for Appointment:')
  let calendarApi = selectInfo.view.calendar

  calendarApi.unselect() // clear date selection

  if (title) {
    calendarApi.addEvent({
      title,
      start: selectInfo.startStr,
      end: selectInfo.endStr,
      allDay: selectInfo.allDay
    })
  }
}

function handleEventClick(clickInfo) {
  if (confirm(`Are you sure you want to delete the event '${clickInfo.event.title}'`)) {
    clickInfo.event.remove()
  }
}
</script>

<template>
  <div class="page-container">
    <div class="page-header">
      <h1>Schedule</h1>
      <button class="btn btn-primary">New Appointment</button>
    </div>
    
    <div class="card calendar-card">
      <FullCalendar :options="calendarOptions" />
    </div>
  </div>
</template>

<style scoped>
.calendar-card {
  height: 700px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}
</style>
