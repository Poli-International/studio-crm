import os
import sys
import ftplib
import re
import requests
import base64
import json
from pathlib import Path

# --- Configuration ---
SOURCE_DIR = Path("c:/Users/Patrick/poli-international/standalone-tools/studio-crm-laravel")
CREDENTIALS_FILE = Path("c:/Users/Patrick/poli-international/January_06-2026-Credentials.md")
REMOTE_BASE_PATH = "/domains/poliinternational.com/public_html/wp-content/standalone-tools/studio-crm"

# --- Credentials Extraction ---
def get_credentials():
    # Adding encoding='utf-8' to prevent 'charmap' errors on Windows
    with open(CREDENTIALS_FILE, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # FTP
    ftp_host = re.search(r"\*\*Host:\*\* ([\d\.]+)", content).group(1)
    ftp_user = re.search(r"\*\*Username:\*\* (\w+)", content).group(1)
    ftp_pass = re.search(r"\*\*Password:\*\* ([^\s\n]+)", content).group(1)
    
    # WordPress
    wp_user = re.search(r"\*\*Username:\*\* (admin@[\w\.-]+)", content).group(1)
    wp_pass = re.search(r"\*\*Password:\*\* ([\w ]+)", content).group(1)
    
    return {
        'ftp': {'host': ftp_host, 'user': ftp_user, 'pass': ftp_pass},
        'wp': {'user': wp_user, 'pass': wp_pass}
    }

# --- FTP Upload ---
def upload_files(ftp_creds):
    print(f"Connecting to FTP {ftp_creds['host']}...")
    ftp = ftplib.FTP(ftp_creds['host'])
    ftp.login(ftp_creds['user'], ftp_creds['pass'])
    
    def mkd_p(path):
        parts = path.split('/')
        current = ""
        for part in parts:
            if not part: continue
            current += "/" + part
            try:
                ftp.mkd(current)
            except:
                pass

    print(f"Uploading files to {REMOTE_BASE_PATH}...")
    
    for root, dirs, files in os.walk(SOURCE_DIR):
        # Skip local-only or heavy dirs
        if any(x in root for x in ['.git', 'node_modules', 'vendor']):
            continue
            
        rel_path = os.path.relpath(root, SOURCE_DIR).replace('\\', '/')
        if rel_path == '.':
            remote_path = REMOTE_BASE_PATH
        else:
            remote_path = f"{REMOTE_BASE_PATH}/{rel_path}"
            
        mkd_p(remote_path)
        ftp.cwd(remote_path)
        
        for file in files:
            # Don't upload the deployment script itself
            if file == 'deploy_studio_crm.py': continue
            
            local_file = os.path.join(root, file)
            print(f"Uploading {file}...")
            with open(local_file, 'rb') as f:
                ftp.storbinary(f"STOR {file}", f)
    
    ftp.quit()
    print("FTP Upload Complete.")

# --- WordPress Page Creation ---
def create_wp_page(wp_creds):
    print("Creating/Updating WordPress Page...")
    
    auth_string = f"{wp_creds['user']}:{wp_creds['pass']}"
    auth_base64 = base64.b64encode(auth_string.encode('ascii')).decode('ascii')
    
    headers = {
        'Authorization': f'Basic {auth_base64}',
        'Content-Type': 'application/json'
    }
    
    # Integration HTML wrapping the CRM
    integration_html = f"""
    <div id="studio-crm-container" style="min-height: 800px; width: 100%;">
        <iframe src="https://poliinternational.com/wp-content/standalone-tools/studio-crm/public/index.php" 
                style="width: 100%; height: 1000px; border: none;"
                title="Studio CRM"></iframe>
    </div>
    """
    
    page_data = {
        'title': 'Studio CRM',
        'content': integration_html,
        'status': 'publish',
        'slug': 'studio-crm'
    }
    
    # Check if page exists
    try:
        response = requests.get(
            "https://poliinternational.com/wp-json/wp/v2/pages?slug=studio-crm",
            headers=headers
        )
        
        if response.status_code == 200 and len(response.json()) > 0:
            page_id = response.json()[0]['id']
            url = f"https://poliinternational.com/wp-json/wp/v2/pages/{page_id}"
            print(f"Updating existing page ID: {page_id}")
            res = requests.post(url, headers=headers, json=page_data)
        else:
            url = "https://poliinternational.com/wp-json/wp/v2/pages"
            print("Creating new page...")
            res = requests.post(url, headers=headers, json=page_data)
        
        if res.status_code in [200, 201]:
            print("WordPress integration successful.")
        else:
            print(f"Failed to integrate with WordPress: {res.text}")
    except Exception as e:
        print(f"WP Page Error: {e}")

def main():
    try:
        creds = get_credentials()
        upload_files(creds['ftp'])
        create_wp_page(creds['wp'])
        print("\nDeployment Successful!")
        print("\nNEXT STEPS:")
        print("1. Log into Hostinger hPanel -> phpMyAdmin.")
        print("2. Import 'database/schema.sql' into your 'u978947437_crm' database.")
        print("3. Update your server's .env file with your database password.")
    except Exception as e:
        print(f"Error during deployment: {e}")

if __name__ == "__main__":
    main()
