# Studio CRM - User Guide

Welcome to your new Studio Management System! This guide will help you get started.

## Getting Started

1.  **Login**: Use the email and password provided by your admin.
2.  **Dashboard**: This is your command center. Check here for today's appointments and revenue.

## Core Features

### 1. Client Management
*   Navigate to **Clients** in the sidebar.
*   Click **Add Client** to create a new profile.
*   Click on a client to view their history, forms, and photos.

### 2. Scheduling
*   Navigate to **Schedule**.
*   Click on any time slot to book an appointment.
*   Drag and drop appointments to reschedule them.

### 3. Service Tracking
*   When a tattoo or piercing is done, go to the Client's profile.
*   Click **Start Service** to log the details (ink used, needles, placement).
*   **Important**: Upload a photo of the completed work. This triggers the automated follow-up emails!

### 4. Financials
*   Record deposits and payments in the **Financial** tab.
*   View your commission report at the end of the week.

## Support
For technical issues, contact support@poli-international.com
