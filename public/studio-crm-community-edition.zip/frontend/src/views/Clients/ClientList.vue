<script setup>
import { ref, computed } from 'vue'
import { Plus, Search, Eye } from 'lucide-vue-next'
import { useRouter } from 'vue-router'

const router = useRouter()
const searchQuery = ref('')

// Simulated data
const clients = ref([
  { id: 1, name: 'John Doe', email: 'john@example.com', phone: '555-0123', lastVisit: '2023-11-15' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', phone: '555-0124', lastVisit: '2023-11-20' },
  { id: 3, name: 'Mike Ross', email: 'mike@example.com', phone: '555-0125', lastVisit: '2023-12-01' },
])

const filteredClients = computed(() => {
  return clients.value.filter(client => 
    client.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
    client.email.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

const viewClient = (id) => {
  router.push(`/clients/${id}`)
}
</script>

<template>
  <div class="page-container">
    <div class="page-header">
      <div>
        <h1>Clients</h1>
        <p class="subtitle">Manage your client base</p>
      </div>
      <button class="btn btn-primary flex-center">
        <Plus size="18" style="margin-right: 0.5rem;" /> Add Client
      </button>
    </div>

    <div class="card">
      <div class="toolbar">
        <div class="search-box">
          <Search size="18" class="search-icon" />
          <input 
            type="text" 
            v-model="searchQuery" 
            placeholder="Search by name or email..." 
            class="form-input search-input"
          >
        </div>
      </div>

      <table class="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Contact</th>
            <th>Last Visit</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="client in filteredClients" :key="client.id">
            <td class="font-medium">{{ client.name }}</td>
            <td>
              <div class="contact-info">
                <div>{{ client.email }}</div>
                <div class="text-sm text-muted">{{ client.phone }}</div>
              </div>
            </td>
            <td>{{ client.lastVisit }}</td>
            <td>
              <button class="btn-icon" @click="viewClient(client.id)">
                <Eye size="18" />
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<style scoped>
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.subtitle {
  color: var(--text-muted);
  margin: 0;
}

.flex-center {
  display: flex;
  align-items: center;
}

.toolbar {
  margin-bottom: 1.5rem;
}

.search-box {
  position: relative;
  max-width: 300px;
}

.search-icon {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--text-muted);
}

.search-input {
  padding-left: 2.5rem;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th, .data-table td {
  padding: 1rem;
  text-align: left;
  border-bottom: 1px solid var(--gray-200);
}

.data-table th {
  color: var(--text-muted);
  font-weight: 500;
  font-size: 0.875rem;
}

.font-medium {
  font-weight: 500;
}

.text-sm {
  font-size: 0.875rem;
}

.contact-info {
  display: flex;
  flex-direction: column;
}

.btn-icon {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--gray-600);
  transition: color 0.2s;
}

.btn-icon:hover {
  color: var(--primary);
}
</style>
