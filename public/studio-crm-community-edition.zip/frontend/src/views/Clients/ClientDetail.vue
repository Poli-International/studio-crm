<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { User, Calendar, FileText, AlertTriangle } from 'lucide-vue-next'

const route = useRoute()
const client = ref(null)

// Simulated fetch
onMounted(() => {
  // In real app: axios.get(`/api/clients/${route.params.id}`)
  client.value = {
    id: route.params.id,
    name: 'John Doe',
    email: 'john@example.com',
    phone: '555-0123',
    dob: '1990-05-15',
    medical_history: 'None',
    allergies: 'Latex',
    notes: 'Prefers realistic style.'
  }
})

const activeTab = ref('history')
</script>

<template>
  <div v-if="client" class="client-detail">
    <!-- Header -->
    <div class="profile-header card">
      <div class="profile-main">
        <div class="avatar-placeholder">
          {{ client.name.charAt(0) }}
        </div>
        <div>
          <h1>{{ client.name }}</h1>
          <div class="meta">
            <span>{{ client.email }}</span> • <span>{{ client.phone }}</span>
          </div>
        </div>
      </div>
      <div class="actions">
        <button class="btn btn-primary">Book Appointment</button>
        <button class="btn btn-secondary">Edit Profile</button>
      </div>
    </div>

    <!-- Layout -->
    <div class="grid-layout">
      <!-- Sidebar Info -->
      <div class="info-sidebar">
        <div class="card mb-4" v-if="client.allergies">
          <h3 class="alert-title">
            <AlertTriangle size="18" /> Medical Alerts
          </h3>
          <div class="alert-content">
            <span class="label">Allergies:</span>
            <span class="value red">{{ client.allergies }}</span>
          </div>
        </div>

        <div class="card">
          <h3>Client Details</h3>
          <div class="detail-row">
            <span class="label">DOB:</span>
            <span class="value">{{ client.dob }}</span>
          </div>
          <div class="detail-row">
            <span class="label">Notes:</span>
            <p class="value note-text">{{ client.notes }}</p>
          </div>
        </div>
      </div>

      <!-- Main Content Tabs -->
      <div class="main-tabs card">
        <div class="tabs-header">
          <button 
            :class="['tab-btn', { active: activeTab === 'history' }]"
            @click="activeTab = 'history'"
          >
            Service History
          </button>
          <button 
            :class="['tab-btn', { active: activeTab === 'forms' }]"
            @click="activeTab = 'forms'"
          >
            Forms & Waivers
          </button>
          <button 
            :class="['tab-btn', { active: activeTab === 'photos' }]"
            @click="activeTab = 'photos'"
          >
            Photos
          </button>
        </div>

        <div class="tab-content">
          <div v-if="activeTab === 'history'">
            <div class="empty-state">
              <Calendar size="48" class="text-muted" />
              <p>No service history found.</p>
            </div>
          </div>
          
           <div v-if="activeTab === 'forms'">
            <div class="empty-state">
              <FileText size="48" class="text-muted" />
              <p>No forms signed yet.</p>
              <button class="btn btn-secondary mt-2">Sign Waiver</button>
            </div>
          </div>
          
           <div v-if="activeTab === 'photos'">
            <div class="empty-state">
              <p>No photos uploaded.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.profile-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.profile-main {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}

.avatar-placeholder {
  width: 64px;
  height: 64px;
  background-color: var(--primary);
  color: white;
  font-size: 2rem;
  font-weight: bold;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.meta {
  color: var(--text-muted);
}

.actions {
  display: flex;
  gap: 1rem;
}

.grid-layout {
  display: grid;
  grid-template-columns: 300px 1fr;
  gap: 2rem;
}

.mb-4 { margin-bottom: 1rem; }

.alert-title {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--danger);
  margin-top: 0;
}

.alert-content {
  background-color: #FEF2F2;
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #FECACA;
}

.red { color: var(--danger); font-weight: bold; }

.detail-row {
  margin-bottom: 1rem;
}

.label {
  display: block;
  font-size: 0.875rem;
  color: var(--text-muted);
  margin-bottom: 0.25rem;
}

.tabs-header {
  display: flex;
  border-bottom: 1px solid var(--gray-200);
  margin-bottom: 1.5rem;
}

.tab-btn {
  padding: 1rem 1.5rem;
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  color: var(--text-muted);
  font-weight: 500;
}

.tab-btn.active {
  color: var(--primary);
  border-bottom-color: var(--primary);
}

.empty-state {
  text-align: center;
  padding: 3rem;
  color: var(--text-muted);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}
</style>
