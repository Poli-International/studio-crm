import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/login',
            name: 'login',
            component: () => import('../views/Login.vue')
        },
        {
            path: '/',
            name: 'dashboard',
            component: Dashboard,
            meta: { requiresAuth: true }
        },
        {
            path: '/clients',
            name: 'clients',
            component: () => import('../views/Clients/ClientList.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/clients/:id',
            name: 'client-detail',
            component: () => import('../views/Clients/ClientDetail.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/calendar',
            name: 'calendar',
            component: () => import('../views/Scheduling/Calendar.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/services',
            name: 'services',
            component: () => import('../views/Services/ServiceList.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/financial',
            name: 'financial',
            component: () => import('../views/Financial/FinancialDashboard.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/inventory',
            name: 'inventory',
            component: () => import('../views/Inventory/InventoryList.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/compliance',
            name: 'compliance',
            component: () => import('../views/Compliance/ComplianceDashboard.vue'),
            meta: { requiresAuth: true }
        },
        {
            path: '/settings',
            name: 'settings',
            component: () => import('../views/Settings/SettingsDashboard.vue'),
            meta: { requiresAuth: true }
        }
    ]
})

// Navigation Guard
router.beforeEach((to, from, next) => {
    const isAuthenticated = localStorage.getItem('token')

    if (to.meta.requiresAuth && !isAuthenticated) {
        next({ name: 'login' })
    } else {
        next()
    }
})

export default router
