<script setup>
</script>

<template>
  <div class="page-container">
    <h1>Services</h1>
    <div class="card">
        <p>Service Tracking Module Coming Soon</p>
    </div>
  </div>
</template>
