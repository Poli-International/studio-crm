-- Database Schema for Poli International Studio CRM (Tool #15)
-- Option C: Hybrid Deployment (Free Self-Hosted / Paid Cloud)

SET FOREIGN_KEY_CHECKS=0;

-- -----------------------------------------------------
-- Table: staff
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `staff` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_uuid` VARCHAR(36) NOT NULL COMMENT 'For global identification',
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'manager', 'artist', 'receptionist') NOT NULL DEFAULT 'artist',
  `specialties` TEXT NULL COMMENT 'JSON array of styles/skills',
  `commission_rate` DECIMAL(5,2) DEFAULT 0.00,
  `active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `email_unique` (`email` ASC)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: clients
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `clients` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `dob` DATE NULL,
  `medical_history` TEXT NULL COMMENT 'Encrypted JSON',
  `allergies` TEXT NULL COMMENT 'Encrypted',
  `photo_url` VARCHAR(255) NULL,
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `email_index` (`email` ASC)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: appointments
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `staff_id` INT UNSIGNED NOT NULL,
  `service_type` ENUM('tattoo', 'piercing', 'consultation', 'touchup', 'removal') NOT NULL,
  `datetime` DATETIME NOT NULL,
  `duration_minutes` INT NOT NULL DEFAULT 60,
  `deposit_amount` DECIMAL(10,2) DEFAULT 0.00,
  `status` ENUM('pending', 'confirmed', 'completed', 'cancelled', 'noshow') NOT NULL DEFAULT 'pending',
  `notes` TEXT NULL,
  `google_event_id` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_appt_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_appt_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE RESTRICT
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: services
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `services` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `staff_id` INT UNSIGNED NOT NULL,
  `appointment_id` INT UNSIGNED NULL,
  `type` ENUM('tattoo', 'piercing', 'touchup', 'removal') NOT NULL,
  `body_location` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `details` JSON NULL COMMENT 'Specific details like Ink colors, Needle configs, Jewelry used',
  `date_completed` DATETIME NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_service_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_service_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_service_appt` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE SET NULL
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: service_photos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `service_photos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `service_id` INT UNSIGNED NOT NULL,
  `client_id` INT UNSIGNED NOT NULL,
  `photo_path` VARCHAR(255) NOT NULL,
  `stage` ENUM('before', 'stencil', 'fresh', 'healing', 'healed') NOT NULL DEFAULT 'fresh',
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_photo_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_photo_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: forms
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `forms` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `template_id` INT UNSIGNED NULL COMMENT 'Reference to template if using one',
  `form_type` ENUM('intake', 'consent', 'aftercare', 'waiver') NOT NULL,
  `data` JSON NOT NULL COMMENT 'Form field values',
  `signature_data` LONGTEXT NULL COMMENT 'Base64 signature',
  `signed_at` DATETIME NOT NULL,
  `pdf_path` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_form_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: inventory
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `inventory` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `item_type` ENUM('needle', 'ink', 'jewelry', 'supply', 'equipment') NOT NULL,
  `sku` VARCHAR(50) NULL,
  `quantity` INT NOT NULL DEFAULT 0,
  `reorder_point` INT NOT NULL DEFAULT 5,
  `details` JSON NULL COMMENT 'Specifics like Gauge, Color, Brand, Expiry',
  `supplier_info` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: financial
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `financial` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NULL,
  `service_id` INT UNSIGNED NULL,
  `staff_id` INT UNSIGNED NULL,
  `type` ENUM('deposit', 'payment', 'refund', 'expense') NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `method` ENUM('cash', 'card', 'transfer', 'other') NOT NULL DEFAULT 'cash',
  `transaction_date` DATETIME NOT NULL,
  `status` ENUM('completed', 'pending', 'failed') NOT NULL DEFAULT 'completed',
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_fin_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: email_queue
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `email_queue` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `service_id` INT UNSIGNED NULL,
  `template_slug` VARCHAR(50) NOT NULL COMMENT 'e.g., tattoo_day_1',
  `scheduled_for` DATETIME NOT NULL,
  `sent_at` DATETIME NULL,
  `status` ENUM('pending', 'sent', 'failed', 'cancelled') NOT NULL DEFAULT 'pending',
  `error_log` TEXT NULL,
  `opened` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_scheduled` (`status`, `scheduled_for`),
  CONSTRAINT `fk_email_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: documents
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `documents` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NULL,
  `type` ENUM('id_scan', 'medical_note', 'reference_image', 'other') NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `description` VARCHAR(255) NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_doc_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table: compliance
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `compliance` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `staff_id` INT UNSIGNED NULL,
  `type` ENUM('autoclave_log', 'spore_test', 'maintenance', 'training', 'incident') NOT NULL,
  `log_date` DATE NOT NULL,
  `details` JSON NOT NULL,
  `status` ENUM('pass', 'fail', 'needs_review') NOT NULL DEFAULT 'pass',
  `verified_by` INT UNSIGNED NULL COMMENT 'Manager who verified',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_comp_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE = InnoDB;

SET FOREIGN_KEY_CHECKS=1;
