<script setup>
import { RouterLink } from 'vue-router'
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  PenTool, 
  DollarSign, 
  Package, 
  FileText,
  Settings,
  LogOut
} from 'lucide-vue-next'
import { useRouter } from 'vue-router'

const router = useRouter()

const logout = () => {
  localStorage.removeItem('token')
  router.push('/login')
}
</script>

<template>
  <aside class="sidebar">
    <div class="logo">
      <h2>Studio CRM</h2>
    </div>
    
    <nav class="nav-menu">
      <RouterLink to="/" class="nav-item">
        <LayoutDashboard size="20" />
        <span>Dashboard</span>
      </RouterLink>
      
      <RouterLink to="/clients" class="nav-item">
        <Users size="20" />
        <span>Clients</span>
      </RouterLink>
      
      <RouterLink to="/calendar" class="nav-item">
        <Calendar size="20" />
        <span>Schedule</span>
      </RouterLink>
      
      <RouterLink to="/services" class="nav-item">
        <PenTool size="20" />
        <span>Services</span>
      </RouterLink>
      
      <RouterLink to="/financial" class="nav-item">
        <DollarSign size="20" />
        <span>Financial</span>
      </RouterLink>
      
      <RouterLink to="/inventory" class="nav-item">
        <Package size="20" />
        <span>Inventory</span>
      </RouterLink>
      
      <RouterLink to="/compliance" class="nav-item">
        <FileText size="20" />
        <span>Compliance</span>
      </RouterLink>
    </nav>
    
    <div class="bottom-menu">
      <RouterLink to="/settings" class="nav-item">
        <Settings size="20" />
        <span>Settings</span>
      </RouterLink>
      
      <button @click="logout" class="nav-item logout-btn">
        <LogOut size="20" />
        <span>Logout</span>
      </button>
    </div>
  </aside>
</template>

<style scoped>
.sidebar {
  width: 250px;
  background-color: #1F2937; /* Dark sidebar always */
  color: white;
  display: flex;
  flex-direction: column;
  padding: 1rem;
}

.logo {
  padding: 1rem;
  margin-bottom: 2rem;
  font-weight: bold;
  border-bottom: 1px solid #374151;
}

.nav-menu {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 1rem;
  color: #D1D5DB;
  text-decoration: none;
  border-radius: 6px;
  transition: all 0.2s;
}

.nav-item:hover, .router-link-active {
  background-color: #374151;
  color: white;
}

.logout-btn {
  background: none;
  border: none;
  width: 100%;
  cursor: pointer;
  font-size: 1rem;
}

.bottom-menu {
  margin-top: auto;
  border-top: 1px solid #374151;
  padding-top: 1rem;
}
</style>
