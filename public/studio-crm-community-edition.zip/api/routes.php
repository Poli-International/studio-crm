<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\FinancialController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\ComplianceController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application.
| These routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Public Routes
Route::post('/auth/login', [AuthController::class, 'login']);
Route::post('/auth/register', [AuthController::class, 'register']); // Initial admin setup
Route::post('/auth/forgot-password', [AuthController::class, 'forgotPassword']);

// Protected Routes (Require JWT Auth)
Route::middleware(['auth:api'])->group(function () {

    // Auth & Profile
    Route::post('/auth/logout', [AuthController::class, 'logout']);
    Route::get('/auth/user', [AuthController::class, 'user']);
    Route::put('/auth/profile', [AuthController::class, 'updateProfile']);

    // Clients (Agent 4)
    Route::apiResource('clients', ClientController::class);
    Route::get('clients/{id}/history', [ClientController::class, 'history']);
    Route::post('clients/{id}/photos', [ClientController::class, 'uploadPhoto']);
    Route::get('clients/{id}/forms', [ClientController::class, 'forms']);

    // Appointments / Scheduling (Agent 5)
    Route::apiResource('appointments', AppointmentController::class);
    Route::get('calendar/events', [AppointmentController::class, 'events']); // For FullCalendar
    Route::post('appointments/{id}/cancel', [AppointmentController::class, 'cancel']);
    Route::post('appointments/{id}/reschedule', [AppointmentController::class, 'reschedule']);

    // Services (Agent 6)
    Route::apiResource('services', ServiceController::class);
    Route::post('services/{id}/photos', [ServiceController::class, 'uploadServicePhoto']);
    Route::get('services/type/{type}', [ServiceController::class, 'getByType']); // tattoo, piercing, etc.

    // Financial (Agent 7)
    Route::get('financial/dashboard', [FinancialController::class, 'dashboard']);
    Route::apiResource('payments', FinancialController::class);
    Route::get('financial/revenue', [FinancialController::class, 'revenueReport']);
    Route::get('financial/commissions', [FinancialController::class, 'commissionReport']);

    // Inventory (Agent 8)
    Route::apiResource('inventory', InventoryController::class);
    Route::post('inventory/{id}/restock', [InventoryController::class, 'restock']);
    Route::get('inventory/low-stock', [InventoryController::class, 'lowStockAlerts']);

    // Compliance (Agent 21 - Early integration)
    Route::apiResource('compliance', ComplianceController::class);
    
    // Forms (Integration)
    Route::get('forms/templates', [ClientController::class, 'formTemplates']);
    Route::post('forms/submit', [ClientController::class, 'submitForm']);

});
