<template>
  <div class="page-container">
    <h1>Inventory</h1>
    <div class="card"><p>Inventory Module Coming Soon</p></div>
  </div>
</template>
