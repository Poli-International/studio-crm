<template>
  <div class="page-container">
    <h1>Settings</h1>
    <div class="card"><p>System Configuration Coming Soon</p></div>
  </div>
</template>
