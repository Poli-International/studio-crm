# Studio Compliance Module

This module manages all health and safety regulations for the studio.

## Features

1.  **Sterilization Logs (Autoclave)**
    *   Track every cycle: Temperature, Pressure, Duration.
    *   Link cycles to client appointments (traceability).

2.  **Spore Tests (Biological Monitoring)**
    *   Log weekly/monthly third-party test results.
    *   Alert if a test is missed.

3.  **Equipment Maintenance**
    *   Log cleaning and servicing of tattoo machines, autoclaves, and furniture.

4.  **Training Logs**
    *   Track staff Bloodborne Pathogen (BBP) certification expiry.

## Database Structure

See `database/schema.sql` -> `compliance` table.
JSON `details` column stores flexible data depending on the `type`.

## API

`GET /api/compliance` - List logs.
`POST /api/compliance` - Create new log entry.
