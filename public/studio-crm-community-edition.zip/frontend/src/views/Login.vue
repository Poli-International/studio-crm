<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const email = ref('')
const password = ref('')
const error = ref('')
const router = useRouter()

const handleLogin = async () => {
  try {
    // In a real app: const response = await axios.post('/api/auth/login', { email: email.value, password: password.value })
    // localStorage.setItem('token', response.data.access_token)
    
    // For Prototype: Simulate success
    if (email.value && password.value) {
        localStorage.setItem('token', 'simulated-jwt-token')
        router.push('/')
    } else {
        error.value = 'Please enter email and password'
    }
    
  } catch (err) {
    error.value = 'Invalid credentials'
  }
}
</script>

<template>
  <div class="login-container">
    <div class="login-card">
      <div class="brand">
        <h1>Studio CRM</h1>
        <p>Management System</p>
      </div>
      
      <form @submit.prevent="handleLogin">
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" v-model="email" class="form-input" placeholder="artist@studio.com" required>
        </div>
        
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" v-model="password" class="form-input" placeholder="********" required>
        </div>
        
        <div v-if="error" class="error-msg">{{ error }}</div>
        
        <button type="submit" class="btn btn-primary full-width">Sign In</button>
      </form>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: var(--gray-100);
}

.login-card {
  background: white;
  padding: 2rem;
  border-radius: var(--border-radius);
  box-shadow: var(--shadow-md);
  width: 100%;
  max-width: 400px;
}

.brand {
  text-align: center;
  margin-bottom: 2rem;
}

.brand h1 {
  color: var(--primary);
  margin-bottom: 0.5rem;
}

.full-width {
  width: 100%;
  margin-top: 1rem;
}

.error-msg {
  color: var(--danger);
  font-size: 0.875rem;
  margin-top: 0.5rem;
  text-align: center;
}
</style>
