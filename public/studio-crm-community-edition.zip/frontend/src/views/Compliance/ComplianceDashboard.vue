<template>
  <div class="page-container">
    <h1>Compliance & Docs</h1>
    <div class="card"><p>Compliance Module Coming Soon</p></div>
  </div>
</template>
