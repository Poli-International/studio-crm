<?php
session_start();

$message = '';
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 1) {
        // Step 1: Database Setup
        $host = $_POST['host'];
        $db   = $_POST['name'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        
        try {
            $pdo = new PDO("mysql:host=$host;charset=utf8", $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Create Database if not exists
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db`");
            $pdo->exec("USE `$db`");
            
            // Import Schema
            $sql = file_get_contents(__DIR__ . '/database/schema.sql');
            $pdo->exec($sql);
            
            // Write config file (Simulation)
            $config = "<?php\nconst DB_HOST='$host';\nconst DB_NAME='$db';\nconst DB_USER='$user';\nconst DB_PASS='$pass';\n";
            file_put_contents(__DIR__ . '/config.php', $config);
            
            header('Location: ?step=2');
            exit;
            
        } catch (PDOException $e) {
            $message = "Connection failed: " . $e->getMessage();
        }
    } elseif ($step === 2) {
        // Step 2: Admin Account
        // ... Logic to insert admin into staff table ...
        $message = "Installation Complete! Delete this file and login.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Studio CRM Installer</title>
    <style>
        body { font-family: sans-serif; background: #f4f4f4; padding: 50px; }
        .box { background: white; max-width: 500px; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; }
        button { background: #3B82F6; color: white; border: none; padding: 10px 20px; cursor: pointer; width: 100%; }
        .error { color: red; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="box">
        <h1>Studio CRM Installation</h1>
        
        <?php if($message): ?>
            <div class="error"><?= $message ?></div>
        <?php endif; ?>

        <?php if($step === 1): ?>
            <h2>Step 1: Database Connection</h2>
            <form method="post">
                <input type="text" name="host" placeholder="Database Host (localhost)" required value="localhost">
                <input type="text" name="name" placeholder="Database Name" required>
                <input type="text" name="user" placeholder="Database User" required>
                <input type="password" name="pass" placeholder="Database Password">
                <button type="submit">Install Database</button>
            </form>
        <?php elseif($step === 2): ?>
            <h2>Step 2: Admin Account</h2>
            <form method="post">
                <input type="text" name="admin_name" placeholder="Admin Name" required>
                <input type="email" name="admin_email" placeholder="Admin Email" required>
                <input type="password" name="admin_pass" placeholder="Admin Password" required>
                <button type="submit">Create Admin & Finish</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
