<script setup>
import { ref, onMounted } from 'vue'
import { Calendar, DollarSign, Users, AlertCircle } from 'lucide-vue-next'

const stats = ref({
  appointmentsToday: 5,
  revenueToday: 1250,
  activeClients: 124,
  pendingAlerts: 3
})

// Simulated data fetch
onMounted(() => {
  // fetchDashboardData()
})
</script>

<template>
  <div class="dashboard">
    <header class="page-header">
      <h1>Dashboard</h1>
      <div class="date">{{ new Date().toLocaleDateString() }}</div>
    </header>

    <!-- Stats Grid -->
    <div class="stats-grid">
      <div class="card stat-card">
        <div class="icon-bg blue"><Calendar size="24" /></div>
        <div class="stat-info">
          <h3>Appointments Today</h3>
          <p class="stat-value">{{ stats.appointmentsToday }}</p>
        </div>
      </div>
      
      <div class="card stat-card">
        <div class="icon-bg green"><DollarSign size="24" /></div>
        <div class="stat-info">
          <h3>Revenue Today</h3>
          <p class="stat-value">${{ stats.revenueToday }}</p>
        </div>
      </div>
      
      <div class="card stat-card">
        <div class="icon-bg purple"><Users size="24" /></div>
        <div class="stat-info">
          <h3>Active Clients</h3>
          <p class="stat-value">{{ stats.activeClients }}</p>
        </div>
      </div>
      
      <div class="card stat-card">
        <div class="icon-bg orange"><AlertCircle size="24" /></div>
        <div class="stat-info">
          <h3>Pending Alerts</h3>
          <p class="stat-value">{{ stats.pendingAlerts }}</p>
        </div>
      </div>
    </div>

    <div class="content-grid">
      <div class="card recent-activity">
        <h2>Today's Schedule</h2>
        <div class="activity-list">
          <div class="activity-item">
            <span class="time">10:00 AM</span>
            <span class="detail">Tattoo Session - John Doe</span>
            <span class="status confirmed">Confirmed</span>
          </div>
          <div class="activity-item">
            <span class="time">02:00 PM</span>
            <span class="detail">Piercing - Sarah Smith</span>
            <span class="status pending">Pending</span>
          </div>
          <div class="activity-item">
            <span class="time">04:30 PM</span>
            <span class="detail">Consultation - Mike Ross</span>
            <span class="status confirmed">Confirmed</span>
          </div>
        </div>
      </div>

      <div class="card quick-actions">
        <h2>Quick Actions</h2>
        <div class="action-buttons">
          <button class="btn btn-primary">New Appointment</button>
          <button class="btn btn-primary">Add Client</button>
          <button class="btn btn-secondary">Record Payment</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.icon-bg {
  width: 50px;
  height: 50px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}

.icon-bg.blue { background-color: var(--primary); }
.icon-bg.green { background-color: var(--success); }
.icon-bg.purple { background-color: var(--secondary); }
.icon-bg.orange { background-color: var(--warning); }

.stat-value {
  font-size: 1.5rem;
  font-weight: bold;
  margin: 0;
}

.stat-info h3 {
  margin: 0;
  font-size: 0.875rem;
  color: var(--text-muted);
}

.content-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 1.5rem;
}

.activity-list {
  margin-top: 1rem;
}

.activity-item {
  display: flex;
  justify-content: space-between;
  padding: 1rem 0;
  border-bottom: 1px solid var(--gray-200);
}

.status {
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
  border-radius: 99px;
}

.status.confirmed { background-color: #DEF7EC; color: #03543F; }
.status.pending { background-color: #FEF3C7; color: #92400E; }

.action-buttons {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 1rem;
}

.btn-secondary {
  background-color: var(--secondary);
  color: white;
}
</style>
