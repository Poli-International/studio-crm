# Studio CRM - Free Version

## Installation Instructions

1. Extract this ZIP file to your web server
2. Create a MySQL database for the CRM
3. Run install.php in your browser
4. Follow the setup wizard
5. Start managing your tattoo/piercing studio!

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)

## Support

- Documentation: See /docs folder
- Issues: Contact us at poliinternational.com/contact
- Coffee: If you find this useful, buy us a coffee! ☕
  https://ko-fi.com/C0C81NEXBV

## License

Free for personal and commercial use.
If you modify and redistribute, please credit Poli International.

---

Made with ❤️ by Poli International
https://poliinternational.com
