<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Financial;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class FinancialController extends Controller
{
    public function dashboard()
    {
        $today = Carbon::today();
        $startOfMonth = Carbon::now()->startOfMonth();

        $dailyRevenue = Financial::where('type', 'payment')
            ->whereDate('transaction_date', $today)
            ->sum('amount');
            
        $monthlyRevenue = Financial::where('type', 'payment')
            ->whereDate('transaction_date', '>=', $startOfMonth)
            ->sum('amount');

        return response()->json([
            'daily_revenue' => $dailyRevenue,
            'monthly_revenue' => $monthlyRevenue,
            // Add more metrics
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'client_id' => 'required|exists:clients,id',
            'amount' => 'required|numeric',
            'type' => 'required|in:deposit,payment,refund,expense',
            'method' => 'required|in:cash,card,transfer,other',
            'transaction_date' => 'required|date'
        ]);

        $financial = Financial::create($validated);
        return response()->json($financial, 201);
    }
}
