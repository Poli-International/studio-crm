<template>
  <div class="page-container">
    <h1>Financial Management</h1>
    <div class="card"><p>Financial Module Coming Soon</p></div>
  </div>
</template>
