# Studio CRM API (Backend)

This directory contains the backend logic for the Studio Management CRM (Tool #15).
It follows the MVC pattern typical of Laravel applications.

## Directory Structure

- **Controllers/**: Contains the logic for handling API requests.
- **Models/**: Represents the database tables (Eloquent models).
- **routes.php**: Defines the API endpoints.

## Technology Stack

- **PHP**: Core language.
- **Laravel**: Framework (simulated structure).
- **MySQL**: Database.

## Authentication

Uses JWT (JSON Web Tokens) for authentication.
Middleware checks for the `Authorization: Bearer <token>` header.

## Deployment

For shared hosting, these files would be part of a standard Laravel installation.
ensure the server points to the `public/` directory (not included in this structural draft) and rewrite rules send requests to `index.php`.
